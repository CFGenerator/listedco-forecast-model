# ListedCo 5Y P&L Model Skill

Generate a simple listed-company P&L model from a ticker, including historical 5-year P&L data and a forward 5-year P&L forecast, without relying on a bundled Excel master template.

The skill fetches the latest 5 fiscal years of annual P&L data, builds the workbook structure directly from code, validates the net income bridge against source `NETPROFIT`, generates a simple 5-year forward forecast using embedded assumption logic, and exports a new workbook.

## What It Does

- Accepts a listed-company ticker, such as `688041.SH`
- Fetches annual P&L data through AkShare / Eastmoney
- Builds the workbook layout, formulas, and formatting directly from code
- Generates a simple 5-year forward P&L forecast using the template's assumption block
- Preserves the template's formulas, formatting, and forecast logic
- Validates `Net income = Profit before tax + Tax expenses` against source `NETPROFIT`

## Main Files

- `SKILL.md`: Skill instructions and trigger description
- `assets/template-mapping.json`: Metric-to-row mapping
- `scripts/load_financials.py`: Fetch and normalize historical P&L data
- `scripts/fill_template.py`: Fill the template from prepared JSON
- `scripts/generate_model_from_ticker.py`: End-to-end ticker-to-model generation
- `references/template_mapping.md`: Human-readable template mapping notes

## Usage

Install dependencies as needed:

```bash
pip install akshare openpyxl
```

Generate a model:

```bash
python scripts/generate_model_from_ticker.py 688041.SH output.xlsx
```

The script builds the workbook from code, fills the historical input cells, and writes a new Excel file.

## Forecast Assumptions

The forecast section uses the assumption block generated directly by the workbook-building code.

By default, the projection-period assumptions are set to remain consistent with `2025A`, including:

- Revenue growth
- Gross margin
- Business tax and surcharges as % of sales
- Sales & marketing expenses as % of sales
- General & administration expenses as % of sales
- Research expenses as % of sales
- Other operating expenses as % of sales
- Net interest expenses as % of sales
- Other non-operating income / expenses as % of sales
- Corporate income tax rate

Users should adjust these assumptions based on the company's actual business outlook, industry conditions, and their own forecast view.

## Notes

- This skill is designed for non-financial listed companies.
- Do not use it for banks, insurers, brokers, or other financial institutions.
- Expense rows in the template use negative values.
- `INCOME_TAX` is mapped as `-INCOME_TAX` so tax refunds remain positive in the template.
