---
name: listedco-forecast-model
description: Build a simple 5-year listed-company P&L forecast model from a ticker. Use when the user wants Codex to take a non-financial listed-company ticker, fetch the latest 5 fiscal years of profit-and-loss data, validate the net income bridge against source data, and generate a new Excel model file with the same structured output as the original template, but without depending on a bundled master .xlsx file.
---

# Listedco Forecast Model

## Overview

Use this skill to generate a simple listed-company P&L model from a ticker.

Core outcome:

1. Accept a listed-company `ticker`.
2. Fetch the latest 5 years of annual P&L data.
3. Map the source fields into the code-defined workbook structure.
4. Validate `Net income` against source `NETPROFIT`.
5. Export a new workbook built directly from code.

This skill is for non-financial listed companies and a lightweight P&L model only.

## Workflow

### 1. Confirm the company is in scope

Use this skill for ordinary operating companies.

Do not use this template for:
- Banks
- Insurers
- Brokers
- Other financial institutions with sector-specific statements

### 2. Start from the ticker

Minimum input:
- `ticker`

Supported examples:
- `688041.SH`
- `600519.SH`
- `SH688041`

### 3. Fetch the latest 5 years of annual P&L data

Use `scripts/load_financials.py`.

Current source:
- `AkShare`
- Eastmoney annual profit-sheet endpoint behind `stock_profit_sheet_by_yearly_em`

The script returns:
- `historical_years`
- `historical_financials`
- `raw_records`
- `net_income_validation`
- `validation_issues`

### 4. Validate net income before writing the workbook

Always validate:

- `template Net income = Profit before tax + Tax expenses`
- compare that result with source `NETPROFIT`

If validation shows a mismatch, surface it clearly instead of silently exporting as if the data is clean.

### 5. Build the workbook from code

Read [references/template_mapping.md](references/template_mapping.md) before writing into the workbook.

Use:
- `scripts/fill_template.py` to generate the workbook structure and fill historical inputs
- `scripts/generate_model_from_ticker.py` for end-to-end ticker-to-workbook generation

Rules:
- Do not depend on a bundled `.xlsx` master template
- Build row structure, formulas, and formatting directly in code
- Fill only the historical input cells from source data
- Preserve the same output logic as the original template design

## Execution Rules

- Start from the ticker.
- Fetch 5 years of actual annual P&L history before generating the workbook.
- Keep all expense rows in template sign convention.
- Map tax using `template tax row = -INCOME_TAX`.
- Validate `Net income` against source `NETPROFIT`.
- Flag missing fields instead of inventing values.
- Keep the workbook centered on the income statement.

## File Map

- `scripts/load_financials.py`: Fetch and normalize 5-year historical P&L data.
- `scripts/fill_template.py`: Generate the workbook structure and fill the historical input block.
- `scripts/generate_model_from_ticker.py`: Generate a new Excel model from a ticker.
- `references/metric_definitions.md`: Metric definitions and sign conventions.
- `references/template_mapping.md`: Exact template row and formula rules.
- `assets/template-mapping.json`: Machine-readable mapping between metrics and template rows.
- `assets/template-fill-sample.json`: Minimal example payload for manual fill testing.

## Output Standard

The generated result should include:

- A new Excel workbook generated from code
- 5 years of historical P&L inputs filled into the blue cells
- Preserved forecast formulas and assumptions
- Structured validation output showing whether `Net income` matches source `NETPROFIT`
